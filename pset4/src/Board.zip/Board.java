import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Stack;

/**
 * Created by Xiaojun YU on 2017-02-11.
 */
public class Board {
    private final int[][] board;
    private final int[][] goalBoard;
    private final int n;

    public Board(int[][] blocks)           // construct a board from an n-by-n array of blocks
    {
        this.n = blocks.length;
        board = new int[n][n];
        goalBoard = new int[n][n];
        // num represent the the number in each block in the goal state
        int num = 1;
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                board[i][j] = blocks[i][j];
                goalBoard[i][j] = num;
                num++;
            }
        }
        goalBoard[n - 1][n - 1] = 0;
    }
    // (where blocks[i][j] = block in row i, column j)
    public int dimension()                 // board dimension n
    {
        return this.n;
    }
    public int hamming()                   // number of blocks out of place
    {
        int count = 0;
        // num represent the the number in each block in the goal state
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                if (board[i][j] != goalBoard[i][j] && board[i][j] != 0)
                    count++;
            }
        }
        return count;
    }
    public int manhattan()                 // sum of Manhattan distances between blocks and goal
    {
        int count = 0;
        // num represent the the number in each block in the goal state
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                int goalInt = goalBoard[i][j];
                if (board[i][j] != goalInt && board[i][j] != 0){
                    int rowGoal = goalInt / n;
                    int colGoal = goalInt % n;
                    count += Math.abs(i - rowGoal) + Math.abs(j - colGoal);
                }
            }
        }
        return count;
    }

    private boolean swap(int i, int j, int it, int jt) {
        if(it < 0 || it >= n || jt < 0 || jt >= n) {
            return false;
        }
        int temp = board[i][j];
        board[i][j] = board[it][jt];
        board[it][jt] = temp;
        return true;
    }



    public boolean isGoal()                // is this board the goal board?
    {
        return hamming() == 0;
    }
    public Board twin() {
        Board board = new Board(this.board);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - 1; j++) {
                if (this.board[i][j] != 0 && this.board[i][j + 1] != 0) {
                    board.swap(i, j, i, j + 1);
                    return board;
                }
            }
        }
        return board;
    }

    private boolean isBoard(Board that) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (this.board[i][j] != that.board[i][j]) return false;
            }
        }
        return true;
    }

    public boolean equals(Object y){
        // does this board equal y?
        if (y == this) return true;
        if (y == null) return false;
        if (this.getClass() != y.getClass()) return false;
        Board that = (Board) y;
        return (this.n == that.n && this.isBoard(that));
    }
    public Iterable<Board> neighbors()     // all neighboring boards
    {
        int iZero = 0, jZero = 0;
        boolean found = false;
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++) {
                if (board[i][j] == 0) {
                    iZero = i;
                    jZero = j;
                    found = true;
                    break;
                }
            }
            if (found) break;
        }
        Stack<Board> boards = new Stack<Board>();
        Board that = new Board(this.board);
        if (that.swap(iZero, jZero,iZero + 1, jZero)) {
            boards.push(that);
            that = new Board((this.board));
        }
        if (that.swap(iZero, jZero,iZero, jZero + 1)) {
            boards.push(that);
            that = new Board((this.board));
        }
        if (that.swap(iZero, jZero,iZero - 1, jZero)) {
            boards.push(that);
            that = new Board((this.board));
        }
        if (that.swap(iZero, jZero,iZero, jZero - 1)) {
            boards.push(that);
        }
        return boards;
    }

    public String toString()               // string representation of this board (in the output format specified below)
    {
        StringBuilder sb = new StringBuilder();
        sb.append(n + "\n");
        for (int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                sb.append(this.board[i][j]).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) // unit tests (not graded)
    {
        if (args.length == 0) return;
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);
        System.out.print(initial.toString());
    }
}
